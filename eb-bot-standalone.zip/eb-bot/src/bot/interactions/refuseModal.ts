import {
  EmbedBuilder,
  ModalSubmitInteraction,
} from "discord.js";
import { FIELD_IDS } from "../constants.js";
import { logger } from "../lib/logger.js";

export async function handleRefuseModal(
  interaction: ModalSubmitInteraction,
  targetUserId: string,
): Promise<void> {
  await interaction.deferReply({ ephemeral: true });

  const reason = interaction.fields.getTextInputValue(FIELD_IDS.REASON);

  try {
    const targetUser = await interaction.client.users.fetch(targetUserId);

    const dmEmbed = new EmbedBuilder()
      .setTitle("❌  Reporte Recusado")
      .setDescription(
        "Infelizmente, seu relatório de bug foi analisado e **não pôde ser aceito** pela staff.",
      )
      .addFields({ name: "📋  Motivo", value: reason })
      .setColor(0xe74c3c)
      .setFooter({ text: "Se tiver dúvidas, entre em contato com a staff diretamente." })
      .setTimestamp();

    await targetUser.send({ embeds: [dmEmbed] });

    const originalEmbed = interaction.message?.embeds[0];
    if (interaction.message && originalEmbed) {
      const updatedEmbed = EmbedBuilder.from(originalEmbed)
        .setTitle("🐛  Relatório de Bug — ❌ RECUSADO")
        .setColor(0x95a5a6)
        .setFooter({
          text: `Recusado por ${interaction.user.tag} • ID: ${targetUserId}`,
          iconURL: interaction.user.displayAvatarURL(),
        });

      await interaction.message.edit({ embeds: [updatedEmbed], components: [] });
    }

    await interaction.editReply({
      content: `✅ Relatório recusado! O player foi notificado por DM com o motivo.`,
    });

    logger.info({ targetUserId, staffId: interaction.user.id, reason }, "Bug report refused");
  } catch (err) {
    logger.error({ err, targetUserId }, "Failed to send refuse DM");
    await interaction.editReply({
      content:
        "⚠️ Relatório marcado como recusado, mas não foi possível enviar DM ao player " +
        "(ele pode ter DMs desativadas).",
    });
  }
}

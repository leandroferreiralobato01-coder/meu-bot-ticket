import {
  ActionRowBuilder,
  ModalBuilder,
  StringSelectMenuInteraction,
  TextInputBuilder,
  TextInputStyle,
} from "discord.js";
import { FIELD_IDS, MODAL_IDS, TICKET_TYPES, type TicketType } from "../constants.js";

export async function handleTicketSelectMenu(
  interaction: StringSelectMenuInteraction,
  catDuvida: string,
  catDenuncia: string,
  catRevogacao: string,
): Promise<void> {
  const type = interaction.values[0] as TicketType;

  const categoryMap: Record<TicketType, string> = {
    [TICKET_TYPES.DUVIDA]: catDuvida,
    [TICKET_TYPES.DENUNCIA]: catDenuncia,
    [TICKET_TYPES.REVOGACAO]: catRevogacao,
  };

  const categoryId = categoryMap[type];
  const modalCustomId = `${MODAL_IDS.TICKET}:${type}:${categoryId}`;

  const modal = new ModalBuilder().setCustomId(modalCustomId);

  const nickInput = new TextInputBuilder()
    .setCustomId(FIELD_IDS.NICK)
    .setLabel("Qual é o seu nick no jogo?")
    .setStyle(TextInputStyle.Short)
    .setPlaceholder("Ex: GabrielDev")
    .setRequired(true)
    .setMaxLength(50);

  if (type === TICKET_TYPES.DUVIDA) {
    modal.setTitle("❓ Abrir Ticket de Dúvida");

    const doubtInput = new TextInputBuilder()
      .setCustomId(FIELD_IDS.DOUBT)
      .setLabel("Qual é a sua dúvida?")
      .setStyle(TextInputStyle.Short)
      .setPlaceholder("Ex: Como faço para entrar na facção?")
      .setRequired(true)
      .setMaxLength(100);

    const descInput = new TextInputBuilder()
      .setCustomId(FIELD_IDS.DESCRIPTION)
      .setLabel("Descreva melhor sua dúvida")
      .setStyle(TextInputStyle.Paragraph)
      .setPlaceholder("Forneça mais detalhes para agilizarmos seu atendimento.")
      .setRequired(true)
      .setMaxLength(500);

    modal.addComponents(
      new ActionRowBuilder<TextInputBuilder>().addComponents(nickInput),
      new ActionRowBuilder<TextInputBuilder>().addComponents(doubtInput),
      new ActionRowBuilder<TextInputBuilder>().addComponents(descInput),
    );
  } else if (type === TICKET_TYPES.DENUNCIA) {
    modal.setTitle("🚫 Abrir Ticket de Denúncia");

    const targetInput = new TextInputBuilder()
      .setCustomId(FIELD_IDS.TARGET)
      .setLabel("Quem você quer denunciar?")
      .setStyle(TextInputStyle.Short)
      .setPlaceholder("Ex: PlayerMalicioso123")
      .setRequired(true)
      .setMaxLength(80);

    const motiveInput = new TextInputBuilder()
      .setCustomId(FIELD_IDS.MOTIVE)
      .setLabel("Qual é o motivo da denúncia?")
      .setStyle(TextInputStyle.Paragraph)
      .setPlaceholder("Descreva o que ocorreu com o máximo de detalhes possível.")
      .setRequired(true)
      .setMaxLength(500);

    modal.addComponents(
      new ActionRowBuilder<TextInputBuilder>().addComponents(nickInput),
      new ActionRowBuilder<TextInputBuilder>().addComponents(targetInput),
      new ActionRowBuilder<TextInputBuilder>().addComponents(motiveInput),
    );
  } else {
    modal.setTitle("🔄 Abrir Ticket de Revogação");

    const revokedInput = new TextInputBuilder()
      .setCustomId(FIELD_IDS.REVOKED)
      .setLabel("O que foi revogado? (Ex: ban, mute)")
      .setStyle(TextInputStyle.Short)
      .setPlaceholder("Ex: Ban permanente")
      .setRequired(true)
      .setMaxLength(80);

    const motiveInput = new TextInputBuilder()
      .setCustomId(FIELD_IDS.MOTIVE)
      .setLabel("Por que deseja a revogação?")
      .setStyle(TextInputStyle.Paragraph)
      .setPlaceholder("Explique sua situação com detalhes para que a staff possa analisar.")
      .setRequired(true)
      .setMaxLength(500);

    modal.addComponents(
      new ActionRowBuilder<TextInputBuilder>().addComponents(nickInput),
      new ActionRowBuilder<TextInputBuilder>().addComponents(revokedInput),
      new ActionRowBuilder<TextInputBuilder>().addComponents(motiveInput),
    );
  }

  await interaction.showModal(modal);
}

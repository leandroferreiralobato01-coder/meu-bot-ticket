import {
  EmbedBuilder,
  ModalSubmitInteraction,
} from "discord.js";
import { FIELD_IDS } from "../constants.js";
import { logger } from "../lib/logger.js";

export async function handleQuestionModal(
  interaction: ModalSubmitInteraction,
  targetUserId: string,
): Promise<void> {
  await interaction.deferReply({ ephemeral: true });

  const question = interaction.fields.getTextInputValue(FIELD_IDS.QUESTION);

  try {
    const targetUser = await interaction.client.users.fetch(targetUserId);

    const dmEmbed = new EmbedBuilder()
      .setTitle("❓  A Staff precisa de mais informações")
      .setDescription(
        "Nossa equipe está analisando seu relatório de bug e tem uma pergunta para você:",
      )
      .addFields({ name: "💬  Pergunta da Staff", value: question })
      .setColor(0xf39c12)
      .setFooter({
        text: "Por favor, responda diretamente no canal de suporte do servidor.",
      })
      .setTimestamp();

    await targetUser.send({ embeds: [dmEmbed] });

    await interaction.editReply({
      content: `✅ Pergunta enviada por DM ao player com sucesso!`,
    });

    logger.info({ targetUserId, staffId: interaction.user.id }, "Question sent to player");
  } catch (err) {
    logger.error({ err, targetUserId }, "Failed to send question DM");
    await interaction.editReply({
      content:
        "⚠️ Não foi possível enviar DM ao player (ele pode ter DMs desativadas). " +
        "Entre em contato diretamente pelo servidor.",
    });
  }
}

import {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  CategoryChannel,
  ChannelType,
  EmbedBuilder,
  ModalSubmitInteraction,
  PermissionFlagsBits,
  TextChannel,
} from "discord.js";
import { BUTTON_IDS, FIELD_IDS, TICKET_TYPES, type TicketType } from "../constants.js";
import { logger } from "../lib/logger.js";

const typeConfig: Record<
  TicketType,
  { label: string; emoji: string; color: number }
> = {
  [TICKET_TYPES.DUVIDA]: { label: "Dúvida", emoji: "❓", color: 0x3498db },
  [TICKET_TYPES.DENUNCIA]: { label: "Denúncia", emoji: "🚫", color: 0xe74c3c },
  [TICKET_TYPES.REVOGACAO]: { label: "Revogação", emoji: "🔄", color: 0xf39c12 },
};

export async function handleTicketModal(
  interaction: ModalSubmitInteraction,
  type: TicketType,
  categoryId: string,
): Promise<void> {
  await interaction.deferReply({ ephemeral: true });

  const guild = interaction.guild;
  if (!guild) {
    await interaction.editReply({ content: "❌ Erro ao criar o ticket." });
    return;
  }

  const category = guild.channels.cache.get(categoryId) as CategoryChannel | undefined;
  if (!category || category.type !== ChannelType.GuildCategory) {
    await interaction.editReply({
      content: "❌ Categoria não encontrada. Peça ao administrador para refazer o `/ticket-setup`.",
    });
    logger.error({ categoryId, type }, "Category not found for ticket");
    return;
  }

  const nick = interaction.fields.getTextInputValue(FIELD_IDS.NICK);
  const config = typeConfig[type];

  let fields: { name: string; value: string }[] = [];

  if (type === TICKET_TYPES.DUVIDA) {
    const doubt = interaction.fields.getTextInputValue(FIELD_IDS.DOUBT);
    const description = interaction.fields.getTextInputValue(FIELD_IDS.DESCRIPTION);
    fields = [
      { name: "🎮  Qual seu nick (Jogo)?", value: nick },
      { name: "❓  Qual é a sua dúvida?", value: doubt },
      { name: "📝  Descrição", value: description },
    ];
  } else if (type === TICKET_TYPES.DENUNCIA) {
    const target = interaction.fields.getTextInputValue(FIELD_IDS.TARGET);
    const motive = interaction.fields.getTextInputValue(FIELD_IDS.MOTIVE);
    fields = [
      { name: "🎮  Qual seu nick (Jogo)?", value: nick },
      { name: "🎯  Quem você quer reportar?", value: target },
      { name: "📋  Motivo do report", value: motive },
    ];
  } else {
    const revoked = interaction.fields.getTextInputValue(FIELD_IDS.REVOKED);
    const motive = interaction.fields.getTextInputValue(FIELD_IDS.MOTIVE);
    fields = [
      { name: "🎮  Qual seu nick (Jogo)?", value: nick },
      { name: "⛔  O que foi revogado?", value: revoked },
      { name: "📋  Motivo da solicitação", value: motive },
    ];
  }

  const channelName = `${config.emoji.replace(/\p{Emoji}/u, "")}-${nick.toLowerCase().replace(/\s+/g, "-").slice(0, 20)}-${Date.now().toString().slice(-4)}`;
  const safeChannelName = channelName.replace(/[^a-z0-9\-]/gi, "").toLowerCase() || `ticket-${Date.now().toString().slice(-6)}`;

  let ticketChannel: TextChannel;
  try {
    ticketChannel = await guild.channels.create({
      name: safeChannelName,
      type: ChannelType.GuildText,
      parent: category,
      permissionOverwrites: [
        {
          id: guild.roles.everyone,
          deny: [PermissionFlagsBits.ViewChannel],
        },
        {
          id: interaction.user.id,
          allow: [
            PermissionFlagsBits.ViewChannel,
            PermissionFlagsBits.SendMessages,
            PermissionFlagsBits.ReadMessageHistory,
          ],
        },
      ],
    });
  } catch (err) {
    logger.error({ err, categoryId, type }, "Failed to create ticket channel");
    await interaction.editReply({
      content: "❌ Não foi possível criar o canal do ticket. Verifique as permissões do bot.",
    });
    return;
  }

  const embed = new EmbedBuilder()
    .setTitle(`${config.emoji}  Ticket de ${config.label}`)
    .setDescription(`${interaction.user} — Bem-vindo ao seu ticket! A staff irá te atender em breve.`)
    .addFields(fields.map((f) => ({ name: f.name, value: f.value, inline: false })))
    .setColor(config.color)
    .setFooter({
      text: `Aberto por ${interaction.user.tag}`,
      iconURL: interaction.user.displayAvatarURL(),
    })
    .setTimestamp();

  const closeRow = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId(BUTTON_IDS.CLOSE_TICKET)
      .setLabel("❌  Termina atendimento")
      .setStyle(ButtonStyle.Danger),
  );

  await ticketChannel.send({
    content: `${interaction.user}`,
    embeds: [embed],
    components: [closeRow],
  });

  await interaction.editReply({
    content: `✅ Seu ticket foi aberto! Acesse ${ticketChannel} para continuar.`,
  });

  logger.info(
    { userId: interaction.user.id, channelId: ticketChannel.id, type },
    "Ticket created",
  );
}

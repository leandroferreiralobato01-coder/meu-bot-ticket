import {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  EmbedBuilder,
  ModalSubmitInteraction,
  TextChannel,
} from "discord.js";
import { BUTTON_IDS, FIELD_IDS } from "../constants.js";
import { logger } from "../lib/logger.js";

export async function handleReportModal(
  interaction: ModalSubmitInteraction,
  staffChannelId: string,
): Promise<void> {
  await interaction.deferReply({ ephemeral: true });

  const nick = interaction.fields.getTextInputValue(FIELD_IDS.NICK);
  const date = interaction.fields.getTextInputValue(FIELD_IDS.DATE);
  const bugTitle = interaction.fields.getTextInputValue(FIELD_IDS.BUG_TITLE);
  const description = interaction.fields.getTextInputValue(FIELD_IDS.DESCRIPTION);

  const guild = interaction.guild;
  if (!guild) {
    await interaction.editReply({ content: "❌ Erro ao processar o reporte." });
    return;
  }

  const staffChannel = guild.channels.cache.get(staffChannelId) as TextChannel | undefined;
  if (!staffChannel || !staffChannel.isTextBased()) {
    await interaction.editReply({
      content: "❌ Canal da staff não encontrado. Contate um administrador.",
    });
    logger.error({ staffChannelId }, "Staff channel not found");
    return;
  }

  const reportEmbed = new EmbedBuilder()
    .setTitle("🐛  Novo Relatório de Bug")
    .setColor(0xe74c3c)
    .addFields(
      { name: "👤  Player", value: nick, inline: true },
      { name: "📅  Data / Hora", value: date, inline: true },
      { name: "\u200B", value: "\u200B", inline: false },
      { name: "🔴  Bug (Título)", value: bugTitle, inline: false },
      { name: "📝  Descrição", value: description, inline: false },
    )
    .setFooter({
      text: `ID do usuário: ${interaction.user.id}`,
      iconURL: interaction.user.displayAvatarURL(),
    })
    .setTimestamp();

  const userId = interaction.user.id;

  const actionRow = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId(`${BUTTON_IDS.ACCEPT_REPORT}:${userId}`)
      .setLabel("✅  Aceitar Relatório")
      .setStyle(ButtonStyle.Success),
    new ButtonBuilder()
      .setCustomId(`${BUTTON_IDS.REFUSE_REPORT}:${userId}`)
      .setLabel("❌  Recusar Relatório")
      .setStyle(ButtonStyle.Danger),
    new ButtonBuilder()
      .setCustomId(`${BUTTON_IDS.QUESTION_REPORT}:${userId}`)
      .setLabel("❓  Fazer uma Pergunta")
      .setStyle(ButtonStyle.Secondary),
  );

  await staffChannel.send({ embeds: [reportEmbed], components: [actionRow] });

  await interaction.editReply({
    content:
      "✅ **Seu reporte foi enviado com sucesso!**\n" +
      "Nossa equipe irá analisar e em breve você receberá uma resposta por mensagem privada.",
  });

  logger.info({ userId, bugTitle }, "Bug report submitted");
}

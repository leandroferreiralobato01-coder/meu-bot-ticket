import { EmbedBuilder, Message } from "discord.js";
import { GoogleGenerativeAI } from "@google/generative-ai";
import { logger } from "../lib/logger.js";

const genAI = new GoogleGenerativeAI(process.env["GEMINI_API_KEY"] ?? "");

const SERVER_KNOWLEDGE = `
Você é o assistente oficial do servidor de Discord do Exército Brasileiro (EB) no Roblox.
Seu nome é Assistente EB.

Responda QUALQUER pergunta dos membros de forma útil, simpática e em português.
Para perguntas sobre o servidor (cargos, hierarquia, regras, link do jogo), use as informações abaixo.
Para perguntas gerais (horas, datas, dúvidas diversas), responda normalmente como um assistente prestativo.
Seja direto e use no máximo 3 parágrafos curtos.
NUNCA responda: IGNORAR

=== INFORMAÇÕES DO SERVIDOR ===

LINK DO JOGO NO ROBLOX:
https://www.roblox.com/pt/games/88194753181424/Ex-rcito-Brasileiro

HIERARQUIA COMPLETA (do mais alto ao mais baixo):

[Governo Federal]
- [Pres] Presidente
- [Vice-Pres] Vice Presidente

[Alto Comando do Exército - ACE]
- [Cmd-Ex] Comandante do Exército
- [Scmd-Ex] Sub-Comandante do Exército

[Oficiais Generais - OFGE]
- [Mal] Marechal
- [Gen Ex] General-de-Exército
- [Gen Div] General-de-Divisão
- [Gen Bda] General-de-Brigada

[Oficiais Superiores - OFSP]
- [Cel] Coronel
- [TenCel] Tenente-Coronel
- [Maj] Major

[Oficiais Intermediários - OFIT]
- [Cap] Capitão

[Oficiais Subalternos - OFSB]
- [1º Ten] Primeiro-Tenente
- [2º Ten] Segundo-Tenente
- [Asp] Aspirante-a-Oficial

[Graduados - GD]
- [ST] Subtenente
- [1º Sgt] Primeiro-Sargento
- [2º Sgt] Segundo-Sargento
- [3º Sgt] Terceiro-Sargento

[Praças - PR]
- [Cb] Cabo
- [Sd] Soldado
- [Rcr] Recruta

CAPACITAÇÃO DE PATENTE (CP) - tempo mínimo entre promoções:
- Recruta → Soldado: sem CP definida
- Soldado → Cabo: 1 dia
- Cabo → 3º Sgt: 2 dias (+ ESA)
- 3º Sgt → 2º Sgt: 4 dias (+ 8 relatórios de recrutamento)
- 2º Sgt → 1º Sgt: 5 dias (+ 10 relatórios)
- 1º Sgt → Subtenente: 8 dias (+ 12 relatórios)
- Subtenente → Aspirante: 14 dias (+ 15 relatórios + EsPCEx)
- Oficiais NÃO têm CP, são promovidos por mérito avaliado pelo ACE

REGRAS RESUMIDAS:
- Trate todos com respeito
- Proibido palavrões e linguagem ofensiva
- Proibido spam, excesso de emojis, mensagens repetitivas
- Proibido divulgar links externos, convites ou propagandas
- Informações pessoais devem ser tratadas com sigilo
- As normas valem dentro e fora do jogo (no Discord também)
`;

const recentlyAnswered = new Map<string, number>();
const COOLDOWN_MS = 15_000;

export async function handleAiMessage(message: Message): Promise<void> {
  if (message.author.bot) return;
  if (!message.guild) return;

  const content = message.content.trim();
  if (!content || content.length < 4) return;

  const cooldownKey = `${message.channelId}:${message.author.id}`;
  const lastAnswered = recentlyAnswered.get(cooldownKey);
  if (lastAnswered && Date.now() - lastAnswered < COOLDOWN_MS) return;

  let answer: string;
  try {
    const model = genAI.getGenerativeModel({ model: "gemini-2.0-flash" });
    const result = await model.generateContent({
      systemInstruction: SERVER_KNOWLEDGE,
      contents: [{ role: "user", parts: [{ text: content }] }],
      generationConfig: { maxOutputTokens: 400 },
    });
    answer = result.response.text().trim();
  } catch (err: any) {
    logger.error({ err }, "Gemini AI reply failed");
    return;
  }

  if (!answer || answer === "IGNORAR" || answer.toUpperCase().startsWith("IGNORAR")) return;

  recentlyAnswered.set(cooldownKey, Date.now());

  const embed = new EmbedBuilder()
    .setColor(0x1a8c2e)
    .setAuthor({
      name: "Assistente EB",
      iconURL:
        "https://upload.wikimedia.org/wikipedia/commons/thumb/0/05/Flag_of_Brazil.svg/320px-Flag_of_Brazil.svg.png",
    })
    .setDescription(answer)
    .setFooter({ text: `Respondendo a ${message.author.username}` })
    .setTimestamp();

  try {
    await message.reply({ embeds: [embed], allowedMentions: { repliedUser: false } });
    logger.info(
      { channelId: message.channelId, userId: message.author.id, q: content.slice(0, 80) },
      "Gemini AI answered in embed",
    );
  } catch (err) {
    logger.error({ err }, "Failed to send AI embed reply");
  }
}

import {
  ActionRowBuilder,
  CategoryChannel,
  ChatInputCommandInteraction,
  EmbedBuilder,
  PermissionFlagsBits,
  StringSelectMenuBuilder,
  StringSelectMenuOptionBuilder,
  TextChannel,
} from "discord.js";
import { SELECT_IDS } from "../constants.js";
import { logger } from "../lib/logger.js";

export async function handleTicketSetupCommand(
  interaction: ChatInputCommandInteraction,
): Promise<void> {
  await interaction.deferReply({ ephemeral: true });

  const canal = interaction.options.getChannel("canal", true) as TextChannel;
  const catDuvida = interaction.options.getChannel("categoria-duvida", true) as CategoryChannel;
  const catDenuncia = interaction.options.getChannel("categoria-denuncia", true) as CategoryChannel;
  const catRevogacao = interaction.options.getChannel("categoria-revogacao", true) as CategoryChannel;

  const guild = interaction.guild;
  if (!guild) {
    await interaction.editReply({ content: "❌ Este comando só pode ser usado em um servidor." });
    return;
  }

  const me = guild.members.me;
  if (!me || !canal.permissionsFor(me).has(PermissionFlagsBits.SendMessages)) {
    await interaction.editReply({
      content: `❌ Não tenho permissão para enviar mensagens em ${canal}.`,
    });
    return;
  }

  const embed = new EmbedBuilder()
    .setTitle("🎫  Central de Atendimento")
    .setDescription(
      "Precisa de ajuda? Selecione abaixo o tipo do seu atendimento e nossa equipe irá te auxiliar.\n\n" +
      "❓ **Dúvida** — Tire suas dúvidas sobre o servidor\n" +
      "🚫 **Denúncia** — Reporte um jogador ou situação\n" +
      "🔄 **Revogação** — Solicite a revisão de uma punição\n\n" +
      "⚠️ *Abra apenas tickets relacionados ao assunto selecionado.*",
    )
    .setColor(0x5865f2)
    .setFooter({ text: "Selecione uma opção no menu abaixo para abrir seu ticket" })
    .setTimestamp();

  const customId = `${SELECT_IDS.TICKET_MENU}:${catDuvida.id}:${catDenuncia.id}:${catRevogacao.id}`;

  const menu = new StringSelectMenuBuilder()
    .setCustomId(customId)
    .setPlaceholder("📋  Selecione o tipo do atendimento...")
    .addOptions(
      new StringSelectMenuOptionBuilder()
        .setLabel("Dúvida")
        .setDescription("Tenho uma dúvida sobre o servidor")
        .setValue("duvida")
        .setEmoji("❓"),
      new StringSelectMenuOptionBuilder()
        .setLabel("Denúncia")
        .setDescription("Quero reportar um jogador ou situação")
        .setValue("denuncia")
        .setEmoji("🚫"),
      new StringSelectMenuOptionBuilder()
        .setLabel("Revogação")
        .setDescription("Quero solicitar revisão de uma punição")
        .setValue("revogacao")
        .setEmoji("🔄"),
    );

  const row = new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(menu);

  await canal.send({ embeds: [embed], components: [row] });

  await interaction.editReply({
    content:
      `✅ **Painel de tickets criado em ${canal}!**\n\n` +
      `📁 Categorias configuradas:\n` +
      `❓ Dúvidas → ${catDuvida.name}\n` +
      `🚫 Denúncias → ${catDenuncia.name}\n` +
      `🔄 Revogações → ${catRevogacao.name}`,
  });

  logger.info(
    { channelId: canal.id, catDuvida: catDuvida.id, catDenuncia: catDenuncia.id, catRevogacao: catRevogacao.id },
    "Ticket setup command executed",
  );
}

import {
  ActionRowBuilder,
  ButtonInteraction,
  EmbedBuilder,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
} from "discord.js";
import { FIELD_IDS, MODAL_IDS } from "../constants.js";
import { logger } from "../lib/logger.js";

export async function handleAcceptReport(
  interaction: ButtonInteraction,
  targetUserId: string,
): Promise<void> {
  await interaction.deferReply({ ephemeral: true });

  const guild = interaction.guild;
  if (!guild) {
    await interaction.editReply({ content: "❌ Erro ao processar a ação." });
    return;
  }

  try {
    const targetUser = await interaction.client.users.fetch(targetUserId);

    const dmEmbed = new EmbedBuilder()
      .setTitle("✅  Reporte Aceito!")
      .setDescription(
        "**Seu bug foi recebido e nossa equipe já está trabalhando nisso!**\n\n" +
        "Agradecemos imensamente por nos ajudar a melhorar o servidor. " +
        "Você será notificado assim que o bug for corrigido. 🚀",
      )
      .setColor(0x2ecc71)
      .setTimestamp();

    await targetUser.send({ embeds: [dmEmbed] });

    const originalEmbed = interaction.message.embeds[0];
    const updatedEmbed = EmbedBuilder.from(originalEmbed)
      .setTitle("🐛  Relatório de Bug — ✅ ACEITO")
      .setColor(0x2ecc71)
      .setFooter({
        text: `Aceito por ${interaction.user.tag} • ID: ${targetUserId}`,
        iconURL: interaction.user.displayAvatarURL(),
      });

    await interaction.message.edit({ embeds: [updatedEmbed], components: [] });

    await interaction.editReply({
      content: `✅ Relatório aceito! O player foi notificado por DM.`,
    });

    logger.info({ targetUserId, staffId: interaction.user.id }, "Bug report accepted");
  } catch (err) {
    logger.error({ err, targetUserId }, "Failed to send accept DM");
    await interaction.editReply({
      content:
        "⚠️ Relatório marcado como aceito, mas não foi possível enviar DM ao player " +
        "(ele pode ter DMs desativadas).",
    });
  }
}

export async function handleRefuseReport(
  interaction: ButtonInteraction,
  targetUserId: string,
): Promise<void> {
  const modal = new ModalBuilder()
    .setCustomId(`${MODAL_IDS.REFUSE_REASON}:${targetUserId}`)
    .setTitle("❌ Recusar Relatório");

  const reasonInput = new TextInputBuilder()
    .setCustomId(FIELD_IDS.REASON)
    .setLabel("Motivo da recusa (será enviado ao player)")
    .setStyle(TextInputStyle.Paragraph)
    .setPlaceholder("Ex: O comportamento descrito é intencional e faz parte do jogo.")
    .setRequired(true)
    .setMaxLength(500);

  modal.addComponents(new ActionRowBuilder<TextInputBuilder>().addComponents(reasonInput));

  await interaction.showModal(modal);
}

export async function handleQuestionReport(
  interaction: ButtonInteraction,
  targetUserId: string,
): Promise<void> {
  const modal = new ModalBuilder()
    .setCustomId(`${MODAL_IDS.QUESTION_TEXT}:${targetUserId}`)
    .setTitle("❓ Fazer Pergunta ao Player");

  const questionInput = new TextInputBuilder()
    .setCustomId(FIELD_IDS.QUESTION)
    .setLabel("Qual pergunta você quer enviar ao player?")
    .setStyle(TextInputStyle.Paragraph)
    .setPlaceholder("Ex: Você consegue reproduzir o bug de forma consistente? Em qual região do mapa ocorreu?")
    .setRequired(true)
    .setMaxLength(500);

  modal.addComponents(new ActionRowBuilder<TextInputBuilder>().addComponents(questionInput));

  await interaction.showModal(modal);
}

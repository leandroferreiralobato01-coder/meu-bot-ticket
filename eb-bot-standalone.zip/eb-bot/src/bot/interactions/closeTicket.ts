import {
  ButtonInteraction,
  EmbedBuilder,
  GuildMember,
  PermissionFlagsBits,
  TextChannel,
} from "discord.js";
import { getGuildConfig } from "../store/guildConfig.js";
import { logger } from "../lib/logger.js";

export async function handleCloseTicket(interaction: ButtonInteraction): Promise<void> {
  const channel = interaction.channel as TextChannel;
  const guild = interaction.guild;

  if (!guild || !channel) {
    await interaction.reply({ content: "❌ Canal não encontrado.", ephemeral: true });
    return;
  }

  const config = getGuildConfig(guild.id);

  if (config.closeTicketRoleId) {
    const member = interaction.member as GuildMember;
    const hasRole = member.roles.cache.has(config.closeTicketRoleId);
    const isAdmin = member.permissions.has(PermissionFlagsBits.Administrator);

    if (!hasRole && !isAdmin) {
      const role = guild.roles.cache.get(config.closeTicketRoleId);
      await interaction.reply({
        content: `❌ Apenas membros com o cargo **${role?.name ?? "Staff"}** podem fechar este atendimento.`,
        ephemeral: true,
      });
      return;
    }
  }

  const me = guild.members.me;
  if (!me || !channel.permissionsFor(me).has(PermissionFlagsBits.ManageChannels)) {
    await interaction.reply({
      content: "❌ Não tenho permissão para fechar este canal.",
      ephemeral: true,
    });
    return;
  }

  const closingEmbed = new EmbedBuilder()
    .setTitle("🔒  Encerrando Atendimento")
    .setDescription(
      `Este ticket foi encerrado por **${interaction.user.tag}**.\n` +
      `O canal será deletado em **5 segundos**.`,
    )
    .setColor(0x95a5a6)
    .setTimestamp();

  await interaction.reply({ embeds: [closingEmbed] });

  logger.info({ channelId: channel.id, closedBy: interaction.user.id }, "Ticket closed");

  setTimeout(async () => {
    try {
      await channel.delete(`Ticket encerrado por ${interaction.user.tag}`);
    } catch (err) {
      logger.error({ err, channelId: channel.id }, "Failed to delete ticket channel");
    }
  }, 5000);
}

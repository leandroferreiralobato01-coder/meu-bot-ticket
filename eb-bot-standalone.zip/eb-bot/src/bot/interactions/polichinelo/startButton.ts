import {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ButtonInteraction,
  CategoryChannel,
  ChannelType,
  EmbedBuilder,
  PermissionFlagsBits,
  TextChannel,
} from "discord.js";
import { activeSessions } from "./store.js";
import { expectedCall } from "./numberWords.js";
import { logger } from "../../lib/logger.js";

export async function handlePolichinelStart(
  interaction: ButtonInteraction,
  targetUserId: string,
  valo: number,
  logChannelId: string,
  errorCategoryId: string,
): Promise<void> {
  if (interaction.user.id !== targetUserId) {
    await interaction.reply({
      content: "❌ **Essa punição não foi para você.**",
      ephemeral: true,
    });
    return;
  }

  await interaction.deferReply({ ephemeral: true });

  const guild = interaction.guild;
  if (!guild) {
    await interaction.editReply({ content: "❌ Erro ao criar o canal." });
    return;
  }

  const category = guild.channels.cache.get(errorCategoryId) as CategoryChannel | undefined;
  const safeParent = category?.type === ChannelType.GuildCategory ? category : undefined;

  const startTime = new Date();
  const estimatedSeconds = valo * 2;
  const endTime = new Date(startTime.getTime() + estimatedSeconds * 1000);

  const formatTime = (d: Date) =>
    d.toLocaleString("pt-BR", { timeZone: "America/Sao_Paulo", hour12: false });

  let channel: TextChannel;
  try {
    channel = await guild.channels.create({
      name: `polichinelo-${interaction.user.username.toLowerCase().replace(/\s+/g, "-").slice(0, 20)}`,
      type: ChannelType.GuildText,
      parent: safeParent,
      permissionOverwrites: [
        { id: guild.roles.everyone, deny: [PermissionFlagsBits.ViewChannel] },
        {
          id: interaction.user.id,
          allow: [
            PermissionFlagsBits.ViewChannel,
            PermissionFlagsBits.SendMessages,
            PermissionFlagsBits.ReadMessageHistory,
          ],
        },
      ],
    });
  } catch (err) {
    logger.error({ err }, "Failed to create polichinelo channel");
    await interaction.editReply({ content: "❌ Não foi possível criar o canal. Verifique as permissões do bot." });
    return;
  }

  activeSessions.set(channel.id, {
    userId: interaction.user.id,
    userTag: interaction.user.tag,
    total: valo,
    current: 0,
    logChannelId,
    errorCategoryId,
    startTime,
  });

  const embed = new EmbedBuilder()
    .setTitle("🏋️  Polichinelo — Iniciando!")
    .setColor(0xf39c12)
    .addFields(
      { name: "👤  Player", value: interaction.user.toString(), inline: true },
      { name: "🏋️  Polichinelo", value: `**${valo}x**`, inline: true },
      { name: "\u200B", value: "\u200B", inline: false },
      { name: "🕐  Iniciando tempo", value: formatTime(startTime), inline: true },
      { name: "⏳  Tempo determinado", value: formatTime(endTime), inline: true },
    )
    .setDescription(
      `${interaction.user} comece agora!\n\n` +
      `Digite exatamente **${expectedCall(1)}** para o primeiro, depois **${expectedCall(2)}**, e assim por diante.\n\n` +
      `⚠️ **Atenção:** As mensagens devem estar em **MAIÚSCULAS** e terminar com **!**`,
    )
    .setColor(0xf39c12)
    .setTimestamp();

  const closeRow = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId("close_ticket")
      .setLabel("❌  Encerrar Canal")
      .setStyle(ButtonStyle.Danger),
  );

  await channel.send({ embeds: [embed], components: [closeRow] });
  await interaction.editReply({ content: `✅ Canal criado! Vá para ${channel}.` });

  logger.info({ channelId: channel.id, userId: interaction.user.id, valo }, "Polichinelo session started");
}

import {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ChatInputCommandInteraction,
  EmbedBuilder,
} from "discord.js";
import { logger } from "../../lib/logger.js";

export async function handlePolichinelCommand(
  interaction: ChatInputCommandInteraction,
): Promise<void> {
  await interaction.deferReply();

  const valo = interaction.options.getInteger("valo", true);
  const usuario = interaction.options.getUser("usuario", true);
  const motivo = interaction.options.getString("motivo", true);
  const logChannel = interaction.options.getChannel("chanellogs", true);
  const errorCategory = interaction.options.getChannel("categoriaerro", true);

  const embed = new EmbedBuilder()
    .setTitle("⚡  Punição — Polichinelo")
    .setColor(0xe74c3c)
    .addFields(
      { name: "👤  Player", value: `${usuario}`, inline: true },
      { name: "🏋️  Polichinelo", value: `**${valo}x**`, inline: true },
      { name: "\u200B", value: "\u200B", inline: false },
      { name: "📋  Motivo", value: motivo, inline: false },
    )
    .setFooter({
      text: `Punido por ${interaction.user.tag}`,
      iconURL: interaction.user.displayAvatarURL(),
    })
    .setTimestamp();

  const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId(`polichinelo_start:${usuario.id}:${valo}:${logChannel.id}:${errorCategory.id}`)
      .setLabel("✅  Iniciar Polichinelo")
      .setStyle(ButtonStyle.Success),
  );

  await interaction.editReply({ embeds: [embed], components: [row] });

  logger.info(
    { punishedId: usuario.id, valo, motivo, staffId: interaction.user.id },
    "Polichinelo command issued",
  );
}

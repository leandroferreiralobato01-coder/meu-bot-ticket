export interface PolichinelSession {
  userId: string;
  userTag: string;
  total: number;
  current: number;
  logChannelId: string;
  errorCategoryId: string;
  startTime: Date;
}

export const activeSessions = new Map<string, PolichinelSession>();

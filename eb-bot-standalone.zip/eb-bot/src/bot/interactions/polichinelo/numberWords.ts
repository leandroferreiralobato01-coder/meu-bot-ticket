const units = [
  "", "UM", "DOIS", "TRÊS", "QUATRO", "CINCO", "SEIS", "SETE", "OITO", "NOVE",
  "DEZ", "ONZE", "DOZE", "TREZE", "QUATORZE", "QUINZE", "DEZESSEIS", "DEZESSETE",
  "DEZOITO", "DEZENOVE",
];
const tens = [
  "", "", "VINTE", "TRINTA", "QUARENTA", "CINQUENTA",
  "SESSENTA", "SETENTA", "OITENTA", "NOVENTA",
];
const hundreds = [
  "", "CENTO", "DUZENTOS", "TREZENTOS", "QUATROCENTOS", "QUINHENTOS",
  "SEISCENTOS", "SETECENTOS", "OITOCENTOS", "NOVECENTOS",
];

export function toPortugueseWord(n: number): string {
  if (n <= 0 || n > 999) return String(n);
  if (n === 100) return "CEM";
  if (n < 20) return units[n] ?? String(n);
  if (n < 100) {
    const t = tens[Math.floor(n / 10)] ?? "";
    const u = units[n % 10] ?? "";
    return u ? `${t} E ${u}` : t;
  }
  const h = hundreds[Math.floor(n / 100)] ?? "";
  const remainder = n % 100;
  if (remainder === 0) return h;
  const rem = toPortugueseWord(remainder);
  return `${h} E ${rem}`;
}

export function expectedCall(n: number): string {
  return `${toPortugueseWord(n)}!`;
}

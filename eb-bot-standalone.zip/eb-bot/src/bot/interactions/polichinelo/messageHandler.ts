import {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  EmbedBuilder,
  Message,
  TextChannel,
  BaseGuildTextChannel,
} from "discord.js";
import { activeSessions } from "./store.js";
import { expectedCall } from "./numberWords.js";
import { logger } from "../../lib/logger.js";

export async function handlePolichinelMessage(message: Message): Promise<void> {
  if (message.author.bot) return;

  const session = activeSessions.get(message.channelId);
  if (!session) return;

  if (message.author.id !== session.userId) return;

  const next = session.current + 1;
  const expected = expectedCall(next);
  const received = message.content.trim();

  const guildChannel = message.channel instanceof BaseGuildTextChannel ? message.channel : null;

  if (received === expected) {
    session.current = next;

    if (session.current >= session.total) {
      activeSessions.delete(message.channelId);

      const doneEmbed = new EmbedBuilder()
        .setTitle("🎉  Polichinelo Concluído!")
        .setDescription(
          `${message.author} completou todos os **${session.total}** polichinelos! Parabéns, atendimento encerrado.`,
        )
        .setColor(0x2ecc71)
        .setTimestamp();

      const closeRow = new ActionRowBuilder<ButtonBuilder>().addComponents(
        new ButtonBuilder()
          .setCustomId("close_ticket")
          .setLabel("❌  Encerrar Canal")
          .setStyle(ButtonStyle.Danger),
      );

      await guildChannel?.send({ embeds: [doneEmbed], components: [closeRow] });

      logger.info({ channelId: message.channelId, userId: session.userId }, "Polichinelo completed");
    }
    return;
  }

  const errorEmbed = new EmbedBuilder()
    .setTitle("❌  Erro na Contagem!")
    .setColor(0xe74c3c)
    .addFields(
      { name: "👤  Player", value: message.author.toString(), inline: true },
      { name: "\u200B", value: "\u200B", inline: false },
      { name: "❌  Enviado (errado)", value: `\`${received}\``, inline: true },
      { name: "✅  Correto", value: `\`${expected}\``, inline: true },
    )
    .setTimestamp();

  await guildChannel?.send({ embeds: [errorEmbed] });

  const guild = message.guild;
  if (!guild) return;

  const logChannel = guild.channels.cache.get(session.logChannelId) as TextChannel | undefined;
  if (!logChannel?.isTextBased()) return;

  const staffEmbed = new EmbedBuilder()
    .setTitle("⚠️  Erro de Polichinelo — Log")
    .setColor(0xe67e22)
    .addFields(
      { name: "👤  Player", value: `${message.author} (\`${message.author.tag}\`)`, inline: false },
      { name: "❌  Erro", value: `\`${received}\``, inline: true },
      { name: "✅  Correto", value: `\`${expected}\``, inline: true },
      { name: "📅  Data", value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: false },
      {
        name: "📊  Progresso",
        value: `${session.current}/${session.total} polichinelos`,
        inline: false,
      },
    )
    .setTimestamp();

  const staffRow = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId(
        `polichinelo_error_ticket:${message.author.id}:${encodeURIComponent(received)}:${session.errorCategoryId}`,
      )
      .setLabel("📂  Criar Canal de Erro")
      .setStyle(ButtonStyle.Danger),
  );

  await logChannel.send({ embeds: [staffEmbed], components: [staffRow] });

  logger.info(
    { channelId: message.channelId, userId: session.userId, received, expected },
    "Polichinelo counting error",
  );
}

import {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ButtonInteraction,
  CategoryChannel,
  ChannelType,
  EmbedBuilder,
  PermissionFlagsBits,
} from "discord.js";
import { logger } from "../../lib/logger.js";

export async function handlePolichinelErrorTicket(
  interaction: ButtonInteraction,
  targetUserId: string,
  errorText: string,
  errorCategoryId: string,
): Promise<void> {
  await interaction.deferReply({ ephemeral: true });

  const guild = interaction.guild;
  if (!guild) {
    await interaction.editReply({ content: "❌ Erro ao criar o canal." });
    return;
  }

  const category = guild.channels.cache.get(errorCategoryId) as CategoryChannel | undefined;
  if (!category || category.type !== ChannelType.GuildCategory) {
    await interaction.editReply({
      content: "❌ Categoria de erro não encontrada. Refaça o comando `/polichinelo`.",
    });
    return;
  }

  let targetUser;
  try {
    targetUser = await interaction.client.users.fetch(targetUserId);
  } catch {
    await interaction.editReply({ content: "❌ Não foi possível encontrar o usuário." });
    return;
  }

  const me = guild.members.me;
  if (!me) {
    await interaction.editReply({ content: "❌ Sem permissão." });
    return;
  }

  const channel = await guild.channels.create({
    name: `erro-${targetUser.username.toLowerCase().replace(/\s+/g, "-").slice(0, 20)}-${Date.now().toString().slice(-4)}`,
    type: ChannelType.GuildText,
    parent: category,
    permissionOverwrites: [
      { id: guild.roles.everyone, deny: [PermissionFlagsBits.ViewChannel] },
      {
        id: me.id,
        allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ManageChannels],
      },
    ],
  });

  const embed = new EmbedBuilder()
    .setTitle("📂  Ticket de Erro — Polichinelo")
    .setColor(0xe74c3c)
    .addFields(
      { name: "👤  Player", value: `${targetUser} (\`${targetUser.tag}\`)`, inline: false },
      { name: "❌  Erro", value: `\`${decodeURIComponent(errorText)}\``, inline: true },
      { name: "📅  Data", value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: false },
    )
    .setFooter({
      text: `Aberto por ${interaction.user.tag}`,
      iconURL: interaction.user.displayAvatarURL(),
    })
    .setTimestamp();

  const closeRow = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId("close_ticket")
      .setLabel("❌  Fechar Atendimento")
      .setStyle(ButtonStyle.Danger),
  );

  await channel.send({ embeds: [embed], components: [closeRow] });

  await interaction.editReply({ content: `✅ Canal de erro criado: ${channel}` });

  logger.info(
    { channelId: channel.id, targetUserId, errorText },
    "Polichinelo error ticket created",
  );
}

import {
  ActionRowBuilder,
  ButtonInteraction,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
} from "discord.js";
import { FIELD_IDS, MODAL_IDS } from "../constants.js";

export async function handleReportButton(
  interaction: ButtonInteraction,
  staffChannelId: string,
): Promise<void> {
  const modal = new ModalBuilder()
    .setCustomId(`${MODAL_IDS.BUG_REPORT}:${staffChannelId}`)
    .setTitle("🐛 Formulário de Reporte de Bug");

  const nickInput = new TextInputBuilder()
    .setCustomId(FIELD_IDS.NICK)
    .setLabel("Qual é o seu nome/nick?")
    .setStyle(TextInputStyle.Short)
    .setPlaceholder("Ex: GabrielDev")
    .setRequired(true)
    .setMaxLength(50);

  const dateInput = new TextInputBuilder()
    .setCustomId(FIELD_IDS.DATE)
    .setLabel("Data e hora do ocorrido")
    .setStyle(TextInputStyle.Short)
    .setPlaceholder("Ex: 18/06/2026 às 14:30")
    .setRequired(true)
    .setMaxLength(50);

  const bugTitleInput = new TextInputBuilder()
    .setCustomId(FIELD_IDS.BUG_TITLE)
    .setLabel("Qual é o bug? (Título)")
    .setStyle(TextInputStyle.Short)
    .setPlaceholder("Ex: Inventário não abre após teleporte")
    .setRequired(true)
    .setMaxLength(100);

  const descriptionInput = new TextInputBuilder()
    .setCustomId(FIELD_IDS.DESCRIPTION)
    .setLabel("Descrição detalhada")
    .setStyle(TextInputStyle.Paragraph)
    .setPlaceholder("Descreva com detalhes o que aconteceu, como reproduzir o bug, etc.")
    .setRequired(true)
    .setMaxLength(1000);

  modal.addComponents(
    new ActionRowBuilder<TextInputBuilder>().addComponents(nickInput),
    new ActionRowBuilder<TextInputBuilder>().addComponents(dateInput),
    new ActionRowBuilder<TextInputBuilder>().addComponents(bugTitleInput),
    new ActionRowBuilder<TextInputBuilder>().addComponents(descriptionInput),
  );

  await interaction.showModal(modal);
}

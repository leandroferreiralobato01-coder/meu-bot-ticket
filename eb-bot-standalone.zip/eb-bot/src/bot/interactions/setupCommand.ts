import {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ChatInputCommandInteraction,
  EmbedBuilder,
  PermissionFlagsBits,
  TextChannel,
} from "discord.js";
import { BUTTON_IDS } from "../constants.js";
import { logger } from "../lib/logger.js";

export async function handleSetupCommand(
  interaction: ChatInputCommandInteraction,
): Promise<void> {
  await interaction.deferReply({ ephemeral: true });

  const reportChannel = interaction.options.getChannel("canal-report", true) as TextChannel;
  const staffChannel = interaction.options.getChannel("canal-staff", true) as TextChannel;

  const guild = interaction.guild;
  if (!guild) {
    await interaction.editReply({ content: "❌ Este comando só pode ser usado em um servidor." });
    return;
  }

  const me = guild.members.me;
  if (!me) {
    await interaction.editReply({ content: "❌ Não foi possível verificar as permissões do bot." });
    return;
  }

  if (!reportChannel.permissionsFor(me).has(PermissionFlagsBits.SendMessages)) {
    await interaction.editReply({
      content: `❌ Não tenho permissão para enviar mensagens em ${reportChannel}.`,
    });
    return;
  }

  const embed = new EmbedBuilder()
    .setTitle("🐛  Reporte de Bugs")
    .setDescription(
      "Encontrou um bug no servidor? Nos ajude a melhorar sua experiência!\n\n" +
      "Clique no botão abaixo para abrir o formulário de reporte. " +
      "Nossa equipe analisará seu relatório o mais breve possível.\n\n" +
      "**Antes de reportar, verifique se:**\n" +
      "• O bug ainda é reproduzível\n" +
      "• Você possui todos os detalhes necessários\n" +
      "• O bug ainda não foi reportado anteriormente",
    )
    .setColor(0xe74c3c)
    .setFooter({ text: "Sua contribuição é essencial para melhorarmos o servidor!" })
    .setTimestamp();

  const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId(`${BUTTON_IDS.REPORT_BUG}:${staffChannel.id}`)
      .setLabel("🐛  Reportar Bug")
      .setStyle(ButtonStyle.Danger),
  );

  await reportChannel.send({ embeds: [embed], components: [row] });

  await interaction.editReply({
    content:
      `✅ Painel de reporte de bugs criado em ${reportChannel}!\n` +
      `📋 Relatórios serão enviados para ${staffChannel}.`,
  });

  logger.info(
    { reportChannelId: reportChannel.id, staffChannelId: staffChannel.id },
    "Setup command executed",
  );
}

import { ChatInputCommandInteraction, EmbedBuilder } from "discord.js";
import { guildConfigs } from "../store/guildConfig.js";
import { logger } from "../lib/logger.js";

export async function handleCargoFecharCommand(
  interaction: ChatInputCommandInteraction,
): Promise<void> {
  await interaction.deferReply({ ephemeral: true });

  const role = interaction.options.getRole("cargo", true);
  const guildId = interaction.guildId;

  if (!guildId) {
    await interaction.editReply({ content: "❌ Comando disponível apenas em servidores." });
    return;
  }

  guildConfigs.set(guildId, { closeTicketRoleId: role.id });

  const embed = new EmbedBuilder()
    .setTitle("✅  Cargo configurado")
    .setDescription(`Apenas membros com o cargo ${role} poderão fechar tickets e canais de polichinelo.`)
    .setColor(0x2ecc71)
    .setTimestamp();

  await interaction.editReply({ embeds: [embed] });

  logger.info({ guildId, roleId: role.id, roleName: role.name }, "Close ticket role configured");
}

import { REST, Routes, SlashCommandBuilder, ChannelType } from "discord.js";
import { logger } from "../lib/logger.js";

const commands = [
  new SlashCommandBuilder()
    .setName("cargo-fechar")
    .setDescription("Define qual cargo pode fechar tickets e canais de polichinelo")
    .addRoleOption((o) => o.setName("cargo").setDescription("Cargo com permissao para fechar").setRequired(true))
    .toJSON(),

  new SlashCommandBuilder()
    .setName("polichinelo")
    .setDescription("Aplica punicao de polichinelo a um player")
    .addIntegerOption((o) => o.setName("valo").setDescription("Quantidade de polichinelos").setRequired(true).setMinValue(1).setMaxValue(999))
    .addUserOption((o) => o.setName("usuario").setDescription("Player que recebera a punicao").setRequired(true))
    .addStringOption((o) => o.setName("motivo").setDescription("Motivo da punicao").setRequired(true).setMaxLength(200))
    .addChannelOption((o) => o.setName("chanellogs").setDescription("Canal da staff para logs de erros").addChannelTypes(ChannelType.GuildText).setRequired(true))
    .addChannelOption((o) => o.setName("categoriaerro").setDescription("Categoria para tickets de erro grave").addChannelTypes(ChannelType.GuildCategory).setRequired(true))
    .toJSON(),

  new SlashCommandBuilder()
    .setName("setup")
    .setDescription("Configura o painel de reporte de bugs")
    .addChannelOption((o) => o.setName("canal-report").setDescription("Canal do painel de reporte").addChannelTypes(ChannelType.GuildText).setRequired(true))
    .addChannelOption((o) => o.setName("canal-staff").setDescription("Canal privado da staff").addChannelTypes(ChannelType.GuildText).setRequired(true))
    .toJSON(),

  new SlashCommandBuilder()
    .setName("ticket-setup")
    .setDescription("Configura o painel de tickets")
    .addChannelOption((o) => o.setName("canal").setDescription("Canal onde o menu sera exibido").addChannelTypes(ChannelType.GuildText).setRequired(true))
    .addChannelOption((o) => o.setName("categoria-duvida").setDescription("Categoria para Duvidas").addChannelTypes(ChannelType.GuildCategory).setRequired(true))
    .addChannelOption((o) => o.setName("categoria-denuncia").setDescription("Categoria para Denuncias").addChannelTypes(ChannelType.GuildCategory).setRequired(true))
    .addChannelOption((o) => o.setName("categoria-revogacao").setDescription("Categoria para Revogacoes").addChannelTypes(ChannelType.GuildCategory).setRequired(true))
    .toJSON(),
];

export async function deployCommands(): Promise<void> {
  const token = process.env["DISCORD_TOKEN"];
  const clientId = process.env["DISCORD_CLIENT_ID"];
  const guildId = process.env["DISCORD_GUILD_ID"];
  if (!token || !clientId || !guildId) {
    logger.warn("DISCORD_TOKEN, DISCORD_CLIENT_ID or DISCORD_GUILD_ID not set");
    return;
  }
  const rest = new REST().setToken(token);
  try {
    logger.info("Registering slash commands...");
    await rest.put(Routes.applicationGuildCommands(clientId, guildId), { body: commands });
    logger.info("Slash commands registered successfully");
  } catch (err) {
    logger.error({ err }, "Failed to register slash commands");
  }
}

export const BUTTON_IDS = {
  REPORT_BUG: "report_bug",
  ACCEPT_REPORT: "accept_report",
  REFUSE_REPORT: "refuse_report",
  QUESTION_REPORT: "question_report",
  CLOSE_TICKET: "close_ticket",
  POLICHINELO_START: "polichinelo_start",
  POLICHINELO_ERROR_TICKET: "polichinelo_error_ticket",
} as const;

export const MODAL_IDS = {
  BUG_REPORT: "bug_report_modal",
  REFUSE_REASON: "refuse_reason_modal",
  QUESTION_TEXT: "question_text_modal",
  TICKET: "ticket_modal",
} as const;

export const SELECT_IDS = {
  TICKET_MENU: "ticket_menu",
} as const;

export const FIELD_IDS = {
  NICK: "field_nick",
  DATE: "field_date",
  BUG_TITLE: "field_bug_title",
  DESCRIPTION: "field_description",
  REASON: "field_reason",
  QUESTION: "field_question",
  TARGET: "field_target",
  MOTIVE: "field_motive",
  DOUBT: "field_doubt",
  REVOKED: "field_revoked",
} as const;

export const TICKET_TYPES = {
  DUVIDA: "duvida",
  DENUNCIA: "denuncia",
  REVOGACAO: "revogacao",
} as const;

export type TicketType = (typeof TICKET_TYPES)[keyof typeof TICKET_TYPES];

import { Events, Interaction, Message } from "discord.js";
import { client } from "./client.js";
import { BUTTON_IDS, MODAL_IDS, SELECT_IDS } from "./constants.js";
import { handleSetupCommand } from "./interactions/setupCommand.js";
import { handleReportButton } from "./interactions/reportButton.js";
import { handleReportModal } from "./interactions/reportModal.js";
import { handleAcceptReport, handleRefuseReport, handleQuestionReport } from "./interactions/staffActions.js";
import { handleRefuseModal } from "./interactions/refuseModal.js";
import { handleQuestionModal } from "./interactions/questionModal.js";
import { handleTicketSetupCommand } from "./interactions/ticketSetupCommand.js";
import { handleTicketSelectMenu } from "./interactions/ticketSelectMenu.js";
import { handleTicketModal } from "./interactions/ticketModal.js";
import { handleCloseTicket } from "./interactions/closeTicket.js";
import { handleCargoFecharCommand } from "./interactions/cargoFecharCommand.js";
import { handlePolichinelCommand } from "./interactions/polichinelo/command.js";
import { handlePolichinelStart } from "./interactions/polichinelo/startButton.js";
import { handlePolichinelErrorTicket } from "./interactions/polichinelo/errorTicket.js";
import { handlePolichinelMessage } from "./interactions/polichinelo/messageHandler.js";
import { handleAiMessage } from "./interactions/aiMessageHandler.js";
import { logger } from "../lib/logger.js";

client.once(Events.ClientReady, (c) => {
  logger.info({ tag: c.user.tag }, "Discord bot online");
});

client.on(Events.MessageCreate, async (message: Message) => {
  try { await handlePolichinelMessage(message); } catch (err) { logger.error({ err }, "Polichinelo message error"); }
  try { await handleAiMessage(message); } catch (err) { logger.error({ err }, "AI message error"); }
});

client.on(Events.InteractionCreate, async (interaction: Interaction) => {
  try {
    if (interaction.isChatInputCommand()) {
      if (interaction.commandName === "setup") await handleSetupCommand(interaction);
      else if (interaction.commandName === "ticket-setup") await handleTicketSetupCommand(interaction);
      else if (interaction.commandName === "polichinelo") await handlePolichinelCommand(interaction);
      else if (interaction.commandName === "cargo-fechar") await handleCargoFecharCommand(interaction);
      return;
    }
    if (interaction.isStringSelectMenu()) {
      const [menuId, catDuvida, catDenuncia, catRevogacao] = interaction.customId.split(":");
      if (menuId === SELECT_IDS.TICKET_MENU)
        await handleTicketSelectMenu(interaction, catDuvida ?? "", catDenuncia ?? "", catRevogacao ?? "");
      return;
    }
    if (interaction.isButton()) {
      const parts = interaction.customId.split(":");
      const actionId = parts[0];
      if (actionId === BUTTON_IDS.CLOSE_TICKET) { await handleCloseTicket(interaction); return; }
      if (actionId === BUTTON_IDS.POLICHINELO_START) {
        await handlePolichinelStart(interaction, parts[1] ?? "", parseInt(parts[2] ?? "0", 10), parts[3] ?? "", parts[4] ?? "");
        return;
      }
      if (actionId === BUTTON_IDS.POLICHINELO_ERROR_TICKET) {
        await handlePolichinelErrorTicket(interaction, parts[1] ?? "", parts[2] ?? "", parts[3] ?? "");
        return;
      }
      if (actionId === BUTTON_IDS.REPORT_BUG) { await handleReportButton(interaction, parts[1] ?? ""); return; }
      if (actionId === BUTTON_IDS.ACCEPT_REPORT) { await handleAcceptReport(interaction, parts[1] ?? ""); return; }
      if (actionId === BUTTON_IDS.REFUSE_REPORT) { await handleRefuseReport(interaction, parts[1] ?? ""); return; }
      if (actionId === BUTTON_IDS.QUESTION_REPORT) { await handleQuestionReport(interaction, parts[1] ?? ""); return; }
      return;
    }
    if (interaction.isModalSubmit()) {
      const [modalId, p1, p2] = interaction.customId.split(":");
      if (modalId === MODAL_IDS.TICKET) { await handleTicketModal(interaction, p1 as any, p2 ?? ""); return; }
      if (modalId === MODAL_IDS.BUG_REPORT) { await handleReportModal(interaction, p1 ?? ""); return; }
      if (modalId === MODAL_IDS.REFUSE_REASON) { await handleRefuseModal(interaction, p1 ?? ""); return; }
      if (modalId === MODAL_IDS.QUESTION_TEXT) { await handleQuestionModal(interaction, p1 ?? ""); return; }
    }
  } catch (err) {
    logger.error({ err }, "Unhandled interaction error");
  }
});

export async function startBot(): Promise<void> {
  const token = process.env["DISCORD_TOKEN"];
  if (!token) { logger.warn("DISCORD_TOKEN not set"); return; }
  await client.login(token);
}

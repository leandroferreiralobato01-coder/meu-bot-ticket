export interface GuildConfig {
  closeTicketRoleId?: string;
}

export const guildConfigs = new Map<string, GuildConfig>();

export function getGuildConfig(guildId: string): GuildConfig {
  if (!guildConfigs.has(guildId)) guildConfigs.set(guildId, {});
  return guildConfigs.get(guildId)!;
}
